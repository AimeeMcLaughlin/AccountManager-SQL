﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data.Linq.Mapping;

namespace WpfApplication2
{

        public partial class AccountDatabase : DataContext
        {
            public Table<Customer> Customers;
            public Table<AccountDetail> AccountDetails;
            public Table<Payment> Payments;

            public AccountDatabase(string connection) : base(connection) { }
        }
   
}
