﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data.Linq.Mapping;

namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        AccountDatabase db = new AccountDatabase(@"C:\Users\Aimoi\Documents\Visual Studio 2012\Projects\AccountManager\WpfApplication2\AccountDatabase.mdf");

        public MainWindow()
        {
            InitializeComponent();

            Customer newCust = new Customer();
            newCust.FirstName = "Alfred";
            newCust.LastName = "McLaughlin";
            newCust.Address = "5 Brayland Terrace";
            newCust.City = "Lincoln";
            newCust.Post_Code = "Ln2 5pz";
            newCust.Phonenumber = "07419774604";
            newCust.Email = "Alfred@love.co.uk";
        

            // Add the customer to the Customers table.
            db.Customers.InsertOnSubmit(newCust);

            Console.WriteLine("\nCustomers matching CA before insert");
            /*
            foreach (var c in db.Customers.Where(cust => cust.CustomerID.Contains("CA")))
            {
                Console.WriteLine("{0}, {1}, {2}",
                    c.CustomerID, c.CompanyName, c.Orders.Count);
            }*/
        }

        private void CheckBalance_Click(object sender, RoutedEventArgs e)
        {
            //brings up the option of what account to view then displays the balance
        }

        private void WithdrawMoney_Click(object sender, RoutedEventArgs e)
        {
            //bring up account options then asks user how much to withdraw - then update bank balance
            Customer newCust = new Customer();
        }

        private void TransferMoney_Click(object sender, RoutedEventArgs e)
        {
            //allow user to transfer data from one account to another if they one
            //a popup will appear showing the accounts that user has and the balance in both and the option to transfer 
        }

        private void ViewTransactions_Click(object sender, RoutedEventArgs e)
        {
            /*Payment viewPayments = new Payment();

            var table = db.GetTable<Payment>();

            var query = from result in table select result.BankAccountNumber;*/

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void AdminPortal_Click(object sender, RoutedEventArgs e)
        {
            //login required here so Auth will be required
            //also a new table to store username and passwords for employees - this will take them to a new screen where they can enter new customers and accounts#

            //possibly let the admin deposit money into account 
        }


    }
}
