﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data.Linq.Mapping;

namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {



        public MainWindow()
        {
            InitializeComponent();
            DataContext db = new DataContext(@"C:\Users\Aimoi\Documents\Visual Studio 2012\Projects\AccountManager\WpfApplication2\AccountDatabase.mdf");
        }

        private void CheckBalance_Click(object sender, RoutedEventArgs e)
        {

        }

        private void WithdrawMoney_Click(object sender, RoutedEventArgs e)
        {

        }

        private void TransferMoney_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ViewTransactions_Click(object sender, RoutedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }


    }
}
