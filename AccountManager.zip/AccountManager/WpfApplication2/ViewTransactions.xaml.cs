﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data.Linq;
using System.Data.Linq.Mapping;

namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for ViewTransactions.xaml
    /// </summary>
    public partial class ViewTransactions : Window
    {
        int customerNumber;
        AccountDatabase db = new AccountDatabase(@"C:\Users\Aimoi\Documents\Visual Studio 2012\Projects\AccountManager\WpfApplication2\AccountDatabase.mdf");

        public ViewTransactions(string _customerNumber)
        {
            InitializeComponent();
            customerNumber = Int32.Parse(_customerNumber);
            AccountDetail Cust = new AccountDetail();
            
            var query = from customer in db.AccountDetails
                        where customer.CustomerID == customerNumber
                        select customer.TypeofAccount;
            
            /*
                        join accounts in db.AccountDetails on person equals accounts.CustomerID
                        where CustomerID = _customerNumber*/

            StringBuilder MyStringBuilder = new StringBuilder();

            foreach (var c in query)
            {
                string myString = Cust.TypeofAccount;
                MyStringBuilder.Append(Cust.TypeofAccount);
            }
            String thisString = MyStringBuilder.ToString();


            textBox.Text = thisString;
        }


        private void CurrentAccount_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SavingsAccount_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ISA_Click(object sender, RoutedEventArgs e)
        {

        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
     

    }
}
