﻿SELECT AccountDetails.BankAccountNumber, Customer.CustomerID, AccountDetails.TypeofAccount
FROM Customer
INNER JOIN AccountDetails
ON Customer.CustomerID=AccountDetails.CustomerID;