﻿CREATE TABLE [dbo].[Table]
(
	[AccountNumber] INT NOT NULL PRIMARY KEY, 
    [FirstName] NCHAR(50) NULL, 
    [LastName] NCHAR(50) NOT NULL, 
    [Address] NCHAR(50) NULL, 
    [City] NCHAR(50) NULL, 
    [PostCode] VARCHAR(50) NOT NULL, 
    [Telephone] NCHAR(10) NULL, 
    [Email] NCHAR(50) NULL
)
